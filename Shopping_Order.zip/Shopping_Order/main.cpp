#include <iostream>
#include "inc/Customer.h"
#include "inc/product.h"
#include "inc/Discount.h"
#include "inc/Order.h"
using namespace std;

int main()
{
    Customer c;
    c.setCustomerDetails("Rohan", "Bangalore", "9876543210");

    Product p;
    p.setProductDetails("Laptop", 60000, 1);

    Discount d;
    d.setDiscount(10); // 10% off

    Order o;
    o.setOrderId("ORD101");
    o.setCustomer(c);
    o.setProduct(p);
    o.setDiscount(d);

    o.processOrder();
    o.displayOrderSummary();

    return 0;
}
