#include <iostream>
using namespace std;

#include "../inc/Order.h"

Order::Order() : orderId(""), finalAmount(0.0) {}

void Order::setOrderId(string id)
{
    orderId = id;
}

void Order::setCustomer(Customer c)
{
    customer = c;
}

void Order::setProduct(Product p)
{
    product = p;
}

void Order::setDiscount(Discount d)
{
    discount = d;
}

void Order::processOrder()
{
    float amount = product.calculateProductTotal();  

    finalAmount = discount.applyDiscount(amount); 

    cout << "Order processed successfully!" << endl;
}

void Order::displayOrderSummary()
{
    cout << "------------------------" << endl;
    cout << "Order ID   : " << orderId << endl;

    customer.displayCustomer();
    product.displayProduct();

    cout << "Final Amount After Discount: " << finalAmount << endl;
    cout << "------------------------" << endl;
}
