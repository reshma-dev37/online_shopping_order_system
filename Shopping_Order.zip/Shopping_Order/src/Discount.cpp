#include<iostream>
using namespace std;
#include "../inc/Discount.h"

Discount::Discount():discountPercent(0.0){}
void Discount::setDiscount(float percent)
{
    discountPercent = percent;
}
float Discount::applyDiscount(float amount)
{
      float discountAmount =  amount*(discountPercent/100);
      return amount - discountAmount;
}