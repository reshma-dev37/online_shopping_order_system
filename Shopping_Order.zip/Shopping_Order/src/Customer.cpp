#include<iostream>
using namespace std;

#include"../inc/Customer.h"

Customer::Customer():customerName(""),address(""),phone(""){}
void Customer::setCustomerDetails(string name,string address,string phone)
{
    customerName =name;
    this->address = address;
    this->phone =phone;
}
void Customer::displayCustomer()
{
    cout<<"Customer Details :"<<endl;
    cout<<"Customer Name:"<<customerName<<endl;
    cout<<"Address:"<<address<<endl;
    cout<<"Phone is:"<<phone<<endl;
    cout<<"-----------------------"<<endl;
}
