#include<iostream>
using namespace std;

#include"../inc/product.h"

Product::Product():productName(""),price(0.0),quantity(0)
{
}
void Product::setProductDetails(string productName,float price,int quantity)
{
    this->productName = productName;
    this->price = price;
    this->quantity = quantity;

}

void Product::displayProduct()
{
    cout<<"Product details:"<<endl;
    cout<<"Product Name:"<<productName<<endl;
    cout<<"Price:"<<price<<endl;
    cout<<"Quantity:"<<quantity<<endl;
}

float Product::calculateProductTotal()
{
    return quantity*price;
}