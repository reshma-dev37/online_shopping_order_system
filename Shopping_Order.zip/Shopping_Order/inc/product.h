#ifndef PRODUCT_H
#define PRODUCT_H

#include<string>
class Product
{
    private:
    std::string productName;
    float price;
    int quantity;

    public:
    Product();
    void setProductDetails(std::string productName,float price,int quantity);
    void displayProduct();
    float calculateProductTotal();
};
#endif