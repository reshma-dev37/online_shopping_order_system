#ifndef ORDER_H
#define ORDER_H

#include <string>
#include "Customer.h"
#include "product.h"
#include "Discount.h"

class Order
{
private:
    std::string orderId;
    Customer customer;
    Product product;
    Discount discount;
    float finalAmount;

public:
    Order();

    void setOrderId(std::string id);
    void setCustomer(Customer c);
    void setProduct(Product p);
    void setDiscount(Discount d);

    void processOrder();
    void displayOrderSummary();
};

#endif
