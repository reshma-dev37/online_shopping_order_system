#ifndef DISCOUNT_H
#define DISCOUNT_H

class Discount
{
    private:
    float discountPercent;

    public:
    Discount();
    void setDiscount(float percent);
    float applyDiscount(float amount);
};
#endif