#ifndef CUSTOMER_H
#define CUSTOMER_H

#include<string>

class Customer
{
    private:
    std::string customerName;
    std::string address;
    std::string phone;

    public:
    Customer();
    void setCustomerDetails(std::string name, std::string address,std::string phone);
    void displayCustomer();
};
#endif